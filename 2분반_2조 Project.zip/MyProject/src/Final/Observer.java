
package Final;

public interface Observer {
  void update(boolean alarm) ; // 상태 업데이트

}
