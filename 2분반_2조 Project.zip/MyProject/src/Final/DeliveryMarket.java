/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final;

import Final.*;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author 사용자
 */
public class DeliveryMarket {
  Event mondayEvent = new MondayEvent();
    public void Deliveryready() {
        System.out.println("배송 준비");
    }
    public void normalquick(){
        System.out.println("보통 퀵 호출");
    }
    public void fastquick(){
        System.out.println("빠른 퀵 호출");
    }
    public void cancle(){
        System.out.println("호출 취소");
    }
       
    public void normaldeliverystart() {
        Timer timer = new Timer();
        TimerTask timertask = new TimerTask() {
            @Override
            public void run() {
                System.out.println("배송을 시작했습니다");
            }
        };
        timer.schedule(timertask, 5000);
        System.out.println("준비중...");

    }
    public void normaldelivering() {
        Timer timer = new Timer();
        TimerTask timertask = new TimerTask() {
            @Override
            public void run() {
                System.out.println("배송중...");
            }
        };
        timer.schedule(timertask, 7000);
    }
    public void normalDeliverycomplete() {
        Timer timer = new Timer();
        TimerTask timertask = new TimerTask() {
            @Override
            public void run() {
                System.out.println("배달 완료!");
            }
        };
        timer.schedule(timertask, 10000);
    }
    public void fastdeliverystart() {
        Timer timer = new Timer();
        TimerTask timertask = new TimerTask() {
            @Override
            public void run() {
                System.out.println("배송을 시작했습니다");
            }
        };
        timer.schedule(timertask, 5000);
        System.out.println("준비중...");

    }
    public void fastdelivering() {
        Timer timer = new Timer();
        TimerTask timertask = new TimerTask() {
            @Override
            public void run() {
                System.out.println("배송중...");
            }
        };
        timer.schedule(timertask, 5500);
    }
    public void fastDeliverycomplete() {
        Timer timer = new Timer();
        TimerTask timertask = new TimerTask() {
            @Override
            public void run() {
                System.out.println("배달 완료!");
            }
        };
        timer.schedule(timertask, 7000 );
    }
}
