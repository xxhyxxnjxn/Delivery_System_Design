
package Final;

import java.util.Scanner;

class Pay implements PayBehavior {
  public void pay() {
      System.out.println("결제를 선택할 수 있습니다.");
  }

}
