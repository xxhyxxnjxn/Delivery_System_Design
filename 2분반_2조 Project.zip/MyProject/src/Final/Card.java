
package Final;

import java.util.Scanner;

class Card extends PaymentProgress {
   public void input() {
      System.out.println("카드번호를 입력해주세요.");
      Scanner scan = new Scanner(System.in);
      String number=scan.nextLine();
  }

  public void payment() {
      System.out.println("카드결제를 선택했습니다.");
  }

}
