
package Final;

class Login extends User {
  public Login() {
      payBehavior=new Pay();
      addressBehavior=new Address();
  }

  public void display() {
      System.out.println("로그인을 하였습니다.");
  }

}
