
package Final;

class NoAddress implements AddressBehavior {
  public void address() {
      System.out.println("주소를 적을 수 없습니다.");
  }

}
