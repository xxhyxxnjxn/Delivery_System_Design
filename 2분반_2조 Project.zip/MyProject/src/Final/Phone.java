
package Final;

import java.util.Scanner;

class Phone extends PaymentProgress {
  public void input() {
      Scanner scan = new Scanner(System.in);
      int number;
      System.out.println("휴대폰 번호를 입력해 주세요.");
      number=scan.nextInt();
  }

  public void payment() {
      System.out.println("휴대폰 결제를 선택했습니다.");
  }

}
