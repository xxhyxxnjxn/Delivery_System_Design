/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final;


import Final.Event;

/**
 *
 * @author Bu sut
 */
public abstract class saleEvent implements Event{
    protected Event event;
    
    public saleEvent(Event event){
        this.event = event;
    }
    
    public abstract String getEvent();
}
