/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final;

import Final.*;
import Final.Event;


/**
 *
 * @author Bu sut
 */
public class twoPlusone extends saleEvent {
    public twoPlusone(Event event){
        super(event);
    }

    @Override
    public String getEvent() {
        return "두개를 사면 한개를 더드립니다 "+event.getEvent();
    }   
}
