
package Final;

interface AddressBehavior {
  void address() ;

}
