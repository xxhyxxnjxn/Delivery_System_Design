/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final;

import Final.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 사용자
 */
public class RiderControl {

    Command slot1;

    public void RiderControl() {
    }

    public void setCommand(Command command) {
        slot1 = command;

    }

    public void normalSpeed() {
        slot1.call();
    }

    public void fastSpeed() {
        slot1.call();
    }
}
