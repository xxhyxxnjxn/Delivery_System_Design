
package Final;

import java.util.Scanner;

class Address implements AddressBehavior {
  public void address() {
      System.out.println("주소를 입력할 수 있습니다.");
      System.out.print("주소를 입력해주세요 : ");
      Scanner scanner=new Scanner(System.in,"euc-kr");
      String address=scanner.nextLine();
  }

}
