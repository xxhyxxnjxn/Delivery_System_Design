/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final;

import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author 정현진
 */
public class User1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int i=0;
        Final.Event mondayEvent = new Final.MondayEvent();
        Final.Event tuesdayEvent = new Final.TuesdayEvent();
        Final.Event wednesdayEvent = new Final.WednesdayEvent();
        Final.Event thursdayEvent = new Final.ThursdayEvent();
        Final.Event fridayEvent = new Final.FridayEvent();
        Final.Event saturdayEvent = new Final.SaturdayEvent();
        Final.Event sundayEvent = new Final.SundayEvent();

        Final.Event tensaleEvent = new Final.tensale(mondayEvent);               // decorate.세일이벤트의 이벤트 함수들을 객체화
        Final.Event twentysaleEvent = new Final.twentysale(wednesdayEvent);
        Final.Event deliveryfreeEvent = new Final.deliveryFree(thursdayEvent);

        Final.Event oneplusoneEvent = new Final.onePlusone(tuesdayEvent);       // decorate 원플러스원 이벤트 함수들을 객체화
        Final.Event twoplusoneEvent = new Final.twoPlusone(sundayEvent);

        Final.Event drinkcokeEvent = new Final.drinkCoke(sundayEvent);
        Final.Event drinkbearEvent = new Final.drinkBear(saturdayEvent);
        Final.Event drinkbearandsojuEvent = new Final.drinkBear(new Final.drinkSoju(fridayEvent));
        // 데코레이터 구현의 정석으로 비어와 소주이벤트를 겹쳐서 진행하고 싶을때 구현
        Final.RiderControl remote = new Final.RiderControl();
        Final.DeliveryMarket deliverymarket = new Final.DeliveryMarket();
        Final.NormalquickCommand normalquick = new Final.NormalquickCommand(deliverymarket);
        Final.FastquickCommand fastquick = new Final.FastquickCommand(deliverymarket);

        int day;
        
        User user;
        Scanner scan = new Scanner(System.in);
        int menu=0;
        String agree=" ";
        System.out.println("------------고객------------");
        System.out.println("주문을 시작합니다. 로그인을 하시겠습니까?(y: 로그인, n: 비로그인)");
        String login=scan.nextLine();
        if(login.equals("y")){
           user=new Login();
           user.display();
           user.performAddress();
           user.menu();
           menu=user.menuCheck;
           user.performPay();
           user.selectPayment();
           agree=user.agree;
           if(agree.equals("n")||agree.equals("")){
                System.out.print("요일을 선택하세요(월1 화2 수3 목4 금5 토6 일7) : ");
                day = scan.nextInt();
                if (day == 1) {
                    System.out.println(tensaleEvent.getEvent());
                } else if (day == 2) {
                    System.out.println(oneplusoneEvent.getEvent());
                } else if (day == 3) {
                    System.out.println(drinkbearEvent.getEvent());
                } else if (day == 4) {
                    System.out.println(twentysaleEvent.getEvent());
                } else if (day == 4) {
                    System.out.println(deliveryfreeEvent.getEvent());
                } else if (day == 5) {
                    System.out.println(drinkbearandsojuEvent.getEvent());
                } else if (day == 6) {
                    System.out.println(drinkbearEvent.getEvent());
                } else if (day == 7) {
                    System.out.println(twoplusoneEvent.getEvent());
                } else {
                    System.out.println("잘못 입력하셨습니다.");
                }
                System.out.println("주문을 완료합니다.");
           }
           else{
               System.out.println("주문을 취소합니다.");
           }
        }
        else{
            user=new NoLogin();
            user.display();
            user.performAddress();
            user.menu();
            menu=user.menuCheck;
            user.performPay();
            System.out.println("전화주문으로 바로 넘어갑니다.");
        }
        agree=user.agree;
        if(agree.equals("n")||agree.equals(" ")){
        System.out.println("------------매장-----------");
        if(menu==3){
            System.out.println("중식이므로 빠른퀵");
            remote.setCommand(fastquick);
            remote.fastSpeed();
            i=2;
        }
        else{
            System.out.println("퀵 호출을 선택해 주세요.(1: 일반 퀵, 2: 빠른 퀵)");
            int delivery=scan.nextInt();
            if(delivery==1){
                remote.setCommand(normalquick);
                remote.normalSpeed();
                //System.out.println("일반퀵");
                i=1;
            }
            else{
                remote.setCommand(fastquick);
                remote.fastSpeed();
               // System.out.println("빠른퀵");
                i=2;
            }
        }
        
        String review;
        // 주제 객체
        Store store = new Store();
        UserData userdata = new UserData(store);
        if(i==1){       
       Timer timer = new Timer();
        TimerTask timertask = new TimerTask() {
            @Override
            public void run() {
                String review, answer;
                System.out.println("------------고객------------");
                System.out.println("건의사항을 남겨주세요.");
                Scanner a = new Scanner(System.in);
                review = a.nextLine();
                System.out.println("------------매장------------");
                System.out.println("댓글을 남기겠습니까?(y , n)");
                answer = a.nextLine();
                if(answer.equals("y")){
                    store.setState(true);
                }
            }
        };
        timer.schedule(timertask, 10100 );
        }
        else if(i==2){ 
        Timer timer = new Timer();
        TimerTask timertask = new TimerTask() {
            @Override
            public void run() {
                String review, answer;
                System.out.println("------------고객------------");
                System.out.println("건의사항을 남겨주세요.");
                Scanner a = new Scanner(System.in);
                review = a.nextLine();
                System.out.println("------------매장------------");
                System.out.println("댓글을 남기겠습니까?(y , n)");
                answer = a.nextLine();
                if(answer.equals("y")){
                    store.setState(true);
                }
            }
        };
        timer.schedule(timertask, 7100 );
        }       
        
        }
    }
    
}
