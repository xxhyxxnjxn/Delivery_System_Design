/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final;

import Final.*;
import Final.Event;
import Final.saleEvent;

/**
 *
 * @author Bu sut
 */
public class tensale extends saleEvent{
    public tensale(Event event){
        super(event);
    }

    @Override
    public String getEvent() {
        return "1000원 할인 "+event.getEvent();
    }
}
