
package Final;

interface PayBehavior {
  void pay() ;

}
