/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final;

import Final.*;

/**
 *
 * @author 사용자
 */
public class FastquickCommand implements Command{
    private DeliveryMarket foodmarket;
    
     public FastquickCommand(DeliveryMarket deliverymarket){
         this.foodmarket=deliverymarket;
     }
     public void call() {  
        System.out.println("매장에서 빠른 퀵으로 호출이 들어왔습니다");
        foodmarket.fastquick();
        foodmarket.Deliveryready();
        foodmarket.fastdeliverystart();
        foodmarket.fastdelivering();
        foodmarket.fastDeliverycomplete();
    }
}
