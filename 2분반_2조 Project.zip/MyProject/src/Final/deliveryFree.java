/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Final;

import Final.*;
import Final.Event;
import Final.saleEvent;
/**
 *
 * @author 사용자
 */
public class deliveryFree extends saleEvent{
    public deliveryFree (Event event){
        super(event);
    }

    @Override
    public String getEvent() {
        return "10번 호출시 한번 공짜로 배달 "+event.getEvent();
    }
    
}
