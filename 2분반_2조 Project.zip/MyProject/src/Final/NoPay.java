
package Final;

class NoPay implements PayBehavior {
  public void pay() {
      System.out.println("결제를 선택할 수 없습니다.");
  }

}
