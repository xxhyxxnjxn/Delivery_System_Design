/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observerpattern;

/**
 *
 * @author 백민영
 */
public class UserData implements Observer{
    private Store store;

  private boolean alarm;

  public UserData(Store store) {
      this.store = store;
      this.store.registerObserver(this);
  }
  
  public void update(boolean alarm){
      this.behavior(true);
  }
  
  public void behavior(boolean alarm){
      System.out.println("요청하신 건의사항이 잘 처리되었습니다.");
    }   
}
