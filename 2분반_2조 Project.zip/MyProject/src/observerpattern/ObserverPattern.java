/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observerpattern;

import java.util.Scanner;



/**
 *
 * @author 백민영
 */
public class ObserverPattern {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String review;
        // 주제 객체
        Store store = new Store();
        System.out.println("후기를 남겨주세요.");
        Scanner a = new Scanner(System.in);
        review = a.nextLine();

        // 옵저버 객체
        UserData userdata = new UserData(store);
            
        store.setState(true);
       
    }
    
}
