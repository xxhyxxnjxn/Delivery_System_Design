/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observerpattern;

import java.util.LinkedList;

/**
 *
 * @author 백민영
 */
public class Store extends Subject{
    private boolean alarm;
    
    public Store() {
        mObserver = new LinkedList<>();
    }


  public void setState(boolean alarm) {        
      this.alarm = alarm;
      notifyObserver();
      System.out.println("저희 매장을 이용해주셔서 감사합니다. 고객님께서 말씀하신 의견 잘 반영되었습니다. 다음에 또 이용해주세요.");
  }

  public void registerObserver(Observer o) {
    mObserver.add(o);
  }

  public void removeObserver(Observer o) {
    int i = mObserver.indexOf(o);
    if(i>=0){
        mObserver.remove(i);
    }
  }

  public void notifyObserver() {
    mObserver.forEach((observer)->{observer.update(alarm);});
  }
}
