
package observerpattern;

import java.util.List;


public abstract class Subject {
protected List<Observer> mObserver;
    
  public abstract void registerObserver(Observer o) ; // 옵저버 객체 추가

  public abstract void removeObserver(Observer o) ; // 옵저버 객체 삭제

  public abstract void notifyObserver() ; // 옵저버 객제들에게 상태 푸쉬
}
