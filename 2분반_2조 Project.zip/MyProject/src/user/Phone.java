
package user;

class Phone extends PaymentProgress {
  public void input() {
  }

  public void payment() {
  }

}
