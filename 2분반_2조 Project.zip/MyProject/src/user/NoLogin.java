
package user;

class NoLogin extends User {
  public NoLogin() {
      payBehavior=new NoPay();
      addressBehavior=new NoAddress();
  }

  public void display() {
      System.out.println("비로그인으로 주문합니다.");
  }

}
