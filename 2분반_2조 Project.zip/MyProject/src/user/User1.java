/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

import java.util.Scanner;

/**
 *
 * @author 정현진
 */
public class User1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        User user;
        System.out.println("주문을 시작합니다. 로그인을 하시겠습니까?(y: 로그인, n: 비로그인)");
        Scanner scan = new Scanner(System.in);
        String login=scan.nextLine();
        if(login.equals("y")){
           user=new Login();
           user.display();
           user.performAddress();
           user.performPay();
           user.menu();
           user.selectPayment();
        }
        else{
            user=new NoLogin();
            user.display();
            user.performAddress();
            user.performPay();
            user.menu();
        }
        
        System.out.println("주문을 완료합니다.");
    }
    
}
