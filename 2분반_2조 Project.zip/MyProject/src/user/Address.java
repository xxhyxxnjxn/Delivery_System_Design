
package user;

import java.util.Scanner;

class Address implements AddressBehavior {
  public void address() {
      //System.out.print("주소를 입력해주세요 : ");
      //Scanner scanner=new Scanner(System.in,"euc-kr");
      //String address=scanner.nextLine();
      System.out.println("주소를 입력할 수 있습니다.");
  }

}
