
package user;

interface AddressBehavior {
  void address() ;

}
