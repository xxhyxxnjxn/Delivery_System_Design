
package user;

interface PayBehavior {
  void pay() ;

}
