
package user;

import java.util.Scanner;

abstract class User {
  PayBehavior payBehavior;

  AddressBehavior addressBehavior;
  
  PaymentProgress paymentProgress;
  
  int menuCheck;
  int paymentCheck;
  Scanner scan=new Scanner(System.in);
  public User() {
  }

  public abstract void display() ;

  public void performPay() {
      payBehavior.pay();
  }

  public void performAddress() {
      addressBehavior.address();
  }

  public void menu() {
      System.out.println("메뉴를 선택해 주세요. (1: 치킨, 2: 피자, 3: 중식, 4: 한식, 5: 디저트)");
      menuCheck=scan.nextInt();
        if(menuCheck==1){
            System.out.println("치킨을 선택하였습니다.");
        }
        if(menuCheck==2){
            System.out.println("피자를 선택하였습니다.");
        }
        if(menuCheck==3){
            System.out.println("중식을 선택하였습니다.");
        }
        if(menuCheck==4){
            System.out.println("한식을 선택하였습니다.");
        }
        if(menuCheck==3){
            System.out.println("디저트를 선택하였습니다.");
        }
  }

  public void selectPayment() {
      System.out.println("결제를 선택해 주세요. (1: 카드결제, 2: 현금결제, 3: 휴대폰결제)");
      paymentCheck=scan.nextInt();
        if(paymentCheck==1){
             paymentProgress=new Card();
        }
        if(paymentCheck==2){
             paymentProgress=new Money();
        }
        if(paymentCheck==3){
             paymentProgress=new Phone();
        }
        paymentProgress.progress();
  }

}
