
package user;

import java.util.Scanner;

abstract class PaymentProgress {
  public void progress() {
      if(agreement()){
          payment();
          input();
      }
  }

  public boolean agreement() {
      System.out.println("결제를 취소 하시겠습니까? (y : 예, n : 아니요)");
        Scanner scan = new Scanner(System.in);
        String agree=scan.nextLine();
        if(agree.equals("n")){
            return true;
        }
        else{
            System.out.println("결제를 취소합니다.");
            return false;
        }
  }

  public abstract void input() ;

  public abstract void payment() ;

}
