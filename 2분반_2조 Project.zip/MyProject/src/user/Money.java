
package user;

import java.util.Scanner;

class Money extends PaymentProgress {
  public void input() {
      Scanner scan = new Scanner(System.in);
      int number;
      System.out.println("현금영수증을 발행하시겠습니까? (y : 예, n : 아니요)");
        String choice=scan.nextLine();
        if(choice.equals("y")){
            System.out.println("휴대폰 번호를 입력해 주세요.");
            number=scan.nextInt();
        }
        else{
            System.out.println("현금영수증을 발행하지않습니다.");
        }
  }

  public void payment() {
      System.out.println("현금결제를 선택했습니다.");
  }

}
